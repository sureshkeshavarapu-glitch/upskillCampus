import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int choice;

        do {

            System.out.println("\n==================================");
            System.out.println("      MUSIC PLAYER SYSTEM");
            System.out.println("==================================");
            System.out.println("1. View Songs");
            System.out.println("2. Create Playlist");
            System.out.println("3. Add Song to Playlist");
            System.out.println("4. View Playlist");
            System.out.println("5. Remove Song From Playlist");
            System.out.println("6. Play Song");
            System.out.println("7. Pause Song");
            System.out.println("8. Stop Song");
            System.out.println("9. Skip Song");
            System.out.println("10. Exit");
            System.out.print("Enter Your Choice: ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    MusicPlayer.viewSongs();
                    break;

                case 2:
                    sc.nextLine(); // Consume newline
                    MusicPlayer.createPlaylist();
                    break;

                case 3:
                    MusicPlayer.addSongToPlaylist();
                    break;

                case 4:
                    MusicPlayer.viewPlaylist();
                    break;

                case 5:
                    MusicPlayer.removeSongFromPlaylist();
                    break;

                case 6:
                    MusicPlayer.playSong();
                    break;

                case 7:
                    MusicPlayer.pauseSong();
                    break;

                case 8:
                    MusicPlayer.stopSong();
                    break;

                case 9:
                    MusicPlayer.skipSong();
                    break;

                case 10:
                    System.out.println("\nThank You for Using Music Player!");
                    break;

                default:
                    System.out.println("\nInvalid Choice! Please Try Again.");

            }

        } while (choice != 10);

        sc.close();
    }
}