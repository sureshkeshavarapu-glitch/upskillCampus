import java.sql.*;
import java.util.Scanner;

public class MusicPlayer {

    static Scanner sc = new Scanner(System.in);

    static String url = "jdbc:mysql://localhost:3306/musicplayer";
    static String user = "root";
    static String password = "";

    // View Songs
    public static void viewSongs() {

        try {
            Connection con = DriverManager.getConnection(url, user, password);

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery("SELECT * FROM songs");

            System.out.println("\n===== SONG LIST =====");

            while (rs.next()) {

                System.out.println(
                        rs.getInt("id") + " | "
                        + rs.getString("title") + " | "
                        + rs.getString("artist") + " | "
                        + rs.getString("album") + " | "
                        + rs.getString("duration"));
            }

            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // Create Playlist
    public static void createPlaylist() {

        try {

            Connection con = DriverManager.getConnection(url, user, password);

            System.out.print("Enter Playlist Name : ");

            String pname = sc.nextLine();

            PreparedStatement ps =
                    con.prepareStatement("INSERT INTO playlists(playlist_name) VALUES(?)");

            ps.setString(1, pname);

            ps.executeUpdate();

            System.out.println("Playlist Created Successfully.");

            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
    
 // Add Song to Playlist
    public static void addSongToPlaylist() {

        try {

            Connection con = DriverManager.getConnection(url, user, password);

            System.out.print("Enter Playlist ID : ");
            int pid = sc.nextInt();

            System.out.print("Enter Song ID : ");
            int sid = sc.nextInt();

            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO playlist_songs(playlist_id,song_id) VALUES(?,?)");

            ps.setInt(1, pid);
            ps.setInt(2, sid);

            ps.executeUpdate();

            System.out.println("Song Added Successfully.");

            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
 // View Playlist
    public static void viewPlaylist() {

        try {

            Connection con = DriverManager.getConnection(url, user, password);

            System.out.print("Enter Playlist ID: ");
            int playlistId = sc.nextInt();

            String query =
                    "SELECT songs.id, songs.title, songs.artist, songs.album, songs.duration " +
                    "FROM songs " +
                    "INNER JOIN playlist_songs ON songs.id = playlist_songs.song_id " +
                    "WHERE playlist_songs.playlist_id = ?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, playlistId);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n===== PLAYLIST SONGS =====");

            boolean found = false;

            while (rs.next()) {

                found = true;

                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("title") + " | " +
                        rs.getString("artist") + " | " +
                        rs.getString("album") + " | " +
                        rs.getString("duration")
                );

            }

            if (!found) {
                System.out.println("No songs found in this playlist.");
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }
    
 // Remove Song From Playlist
    public static void removeSongFromPlaylist() {

        try {

            Connection con = DriverManager.getConnection(url, user, password);

            System.out.print("Enter Playlist ID: ");
            int playlistId = sc.nextInt();

            System.out.print("Enter Song ID: ");
            int songId = sc.nextInt();

            String query = "DELETE FROM playlist_songs WHERE playlist_id=? AND song_id=?";

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, playlistId);
            ps.setInt(2, songId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Song Removed Successfully!");
            } else {
                System.out.println("Song not found in the playlist.");
            }

            ps.close();
            con.close();

        } catch (Exception e) {

            e.printStackTrace();

        }
    }
    
 // Play Song
    public static void playSong() {

        System.out.println("\n=======================");
        System.out.println("Now Playing...");
        System.out.println("=======================\n");

    }
    
 // Pause Song
    public static void pauseSong() {

        System.out.println("\n=======================");
        System.out.println("Song Paused");
        System.out.println("=======================\n");

    }
    
 // Skip Song
    public static void skipSong() {

        System.out.println("\n=======================");
        System.out.println("Playing Next Song...");
        System.out.println("=======================\n");

    }
    
 // Stop Song
    public static void stopSong() {

        System.out.println("\n=======================");
        System.out.println("Song Stopped");
        System.out.println("=======================\n");

    }

}