import java.util.ArrayList;

public class Playlist {

    private String name;
    private ArrayList<Song> songs;

    public Playlist(String name) {
        this.name = name;
        songs = new ArrayList<>();
    }

    public void addSong(Song song) {
        songs.add(song);
    }

    public void showSongs() {

        System.out.println("\nPlaylist : " + name);

        for (Song s : songs) {
            System.out.println(s.getTitle() + " - " + s.getArtist());
        }
    }
}